/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.Model;

/**
 *
 * @author galaxy
 */
public class InvoiceLine {
    private String item;
    private double price;
    private int count;
    private InvoiceHeader invoice;
    
    public InvoiceLine() {
    }

   

    public InvoiceLine(String item, double price, int count, InvoiceHeader invoice) {
        this.item = item;
        this.price = price;
        this.count = count;
        this.invoice = invoice;
    }

    public double getInvoiceLineTotal(){
     
        return (count*price);
    }
    

    public String getItem() {
        return item;
    }

    public double getPrice() {
        return price;
    }

    public int getCount() {
        return count;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "InvoiceLine{" + "num=" + invoice.getNum() + ", item=" + item + ", price=" + price + ", count=" + count + '}';
    }

    public InvoiceHeader getInvoice() {
        return invoice;
    }
    
    public String getS_Fil(){
    
      return invoice.getNum()+","+item+","+price+","+count;
    }
    
    
    
}
