/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sales.View;


import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author galaxy
 */
public class LineDialog extends JDialog {
private JTextField itemNameField;
private JTextField itemPriceField;
private JTextField itemCountField;
private JLabel  itemNameLbl;
private JLabel  itemCountLbl;
private JLabel  itemPriceLbl;
private JButton okBtn;
private JButton cancelBtn; 
   

public LineDialog(SalesInvoiceFrame frame){
  itemNameField=new JTextField(30);
    itemNameLbl=new JLabel("Item Name:");

    itemCountField= new JTextField(30);
    itemCountLbl=new JLabel("Item count:");
  
    itemPriceField= new JTextField(30);
  itemPriceLbl= new JLabel("Item Price:");
   
  okBtn=new JButton("OK");
   cancelBtn=new JButton("Cancel");
   
   
   okBtn.setActionCommand("createLineOK");
   cancelBtn.setActionCommand("createLineCancel");
   
   okBtn.addActionListener(frame.getCtrl());
   cancelBtn.addActionListener(frame.getCtrl());
   
   setLayout(new GridLayout(4,2));
    add(itemNameLbl);
     add(itemNameField);
   add(itemCountLbl);
   add(itemCountField);
   add(itemPriceLbl);
   add(itemPriceField);
   add(okBtn);
  add(cancelBtn);
  pack();
}


    

    public JTextField getItemNameField() {
        return itemNameField;
    }

    public void setItemNameField(JTextField itemNameField) {
        this.itemNameField = itemNameField;
    }

    public JTextField getItemPriceField() {
        return itemPriceField;
    }

    public void setItemPriceField(JTextField itemPriceField) {
        this.itemPriceField = itemPriceField;
    }

    public JTextField getItemCountField() {
        return itemCountField;
    }

    public void setItemCountField(JTextField itemCountField) {
        this.itemCountField = itemCountField;
    }

   

    

    
    
}
    

